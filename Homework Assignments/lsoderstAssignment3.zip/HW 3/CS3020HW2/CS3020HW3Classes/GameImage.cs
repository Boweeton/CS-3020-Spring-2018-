﻿namespace CS3020HW2
{
    public enum GameImage
    {
        Non,
        Adj1,
        Adj2,
        Adj3,
        Adj4,
        Adj5,
        Adj6,
        Adj7,
        Adj8,
        Mine
    }
}