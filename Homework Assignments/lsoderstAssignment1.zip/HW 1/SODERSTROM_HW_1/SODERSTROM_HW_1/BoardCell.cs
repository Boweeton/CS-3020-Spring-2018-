﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SODERSTROM_HW_1
{
    class BoardCell
    {
        #region Fields



        #endregion

        #region Constructors

        public BoardCell()
        {
            BoardState = ' ';
        }

        #endregion

        #region Properties

        public char BoardState { get; set; }

        #endregion

        #region Methods



        #endregion
    }
}
