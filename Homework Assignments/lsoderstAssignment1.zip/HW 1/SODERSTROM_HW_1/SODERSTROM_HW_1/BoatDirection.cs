﻿namespace SODERSTROM_HW_1
{
    public enum BoatDirection
    {
        Right,
        Down
    }
}