﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SODERSTROM_HW_1
{
    /// <summary>
    /// 
    /// </summary>
    public class Pair2D
    {
        #region Fields



        #endregion

        #region Constructors

        public Pair2D(int newX, int newY)
        {
            X = newX;
            Y = newY;
        }

        #endregion

        #region Properties

        public int X { get; set; }
        public int Y { get; set; }

        #endregion

        #region Methods



        #endregion
    }
}