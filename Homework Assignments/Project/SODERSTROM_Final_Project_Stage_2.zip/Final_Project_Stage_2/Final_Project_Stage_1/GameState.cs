﻿namespace Final_Project_Stage_1
{
    public enum GameState
    {
        HeroChoosingAction,
        HeroChoosingTarget,
        EnemyChoosingAction,
        EnemyChoosingTarget
    }
}