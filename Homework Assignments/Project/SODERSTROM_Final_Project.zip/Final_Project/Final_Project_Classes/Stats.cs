﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Final_Project_Classes
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class Stats
    {
        #region Fields



        #endregion

        #region Constructors



        #endregion

        #region Properties

        public int MostRoundsAchieved { get; set; }

        #endregion

        #region Methods

        #region Public Methods



        #endregion

        #region Protected Methods



        #endregion

        #region Private Methods



        #endregion

        #endregion
    }
}