﻿namespace Final_Project_Classes
{
    public enum CharacterType
    {
        Knight,
        Wizard,
        Cleric,
        Bandito,
        Ogre,
        Cat,
        Dragon
    }
}