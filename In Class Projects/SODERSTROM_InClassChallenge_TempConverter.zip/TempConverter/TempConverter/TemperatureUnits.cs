﻿namespace TempConverter
{
    public enum TemperatureUnits
    {
        Fahrenheit,
        Celsius
    }
}